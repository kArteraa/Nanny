# Nanny - my mentor. Пользовательский интерфейс

## Запуск проекта

Для запуска требуется:

```bash
npm install

npm run dev
```
