import { FC } from "react";

interface WidgetTagContainerProps {}

export const WidgetTagContainer: FC<WidgetTagContainerProps> = ({}) => {
    return <section className="widgets__tag">Tag</section>;
};
